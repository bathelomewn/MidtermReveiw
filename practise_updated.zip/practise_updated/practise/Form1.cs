﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practise
{
    public partial class Form1 : Form
    {
        double cando1;
        double cando2;
        double resultdo;
        double memory1 = 0;
        double memory2 = 0;
        bool initia;

        string operator1;


        public Form1()
        {
            InitializeComponent();
        }

        private void button18_Click(object sender, EventArgs e)

        {
            if (textBox1.Text.Equals("0"))
            {
                textBox1.Clear();
            }
            textBox1.Text = textBox1.Text + "1";
        }

        private void button19_Click(object sender, EventArgs e)


        {
            if (textBox1.Text.Equals("0"))
            {
                textBox1.Clear();
            }
            textBox1.Text = textBox1.Text + "2";
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Equals("0"))
            {
                textBox1.Clear();
            }
            textBox1.Text = textBox1.Text + "3";
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Equals("0"))
            {
                textBox1.Clear();
            }
            textBox1.Text = textBox1.Text + "4";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "5";

        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Equals("0"))
            {
                textBox1.Clear();
            }
            textBox1.Text = textBox1.Text + "6";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Equals("0"))
            {
                textBox1.Clear();
            }
            textBox1.Text = textBox1.Text + "7";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Equals("0"))
            {
                textBox1.Clear();
            }
            textBox1.Text = textBox1.Text + "8";
        }


        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Equals("0"))
            {
                textBox1.Clear();
            }
            textBox1.Text = textBox1.Text + "9";
        }

        private void button22_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 0 && !textBox1.Text.StartsWith("0"))
            {
                textBox1.Text = textBox1.Text + "0";
            }
        }
        private void button23_Click(object sender, EventArgs e)
        {
            if (!textBox1.Text.Contains('.'))
            {
                textBox1.Text = textBox1.Text + ".";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button24_Click(object sender, EventArgs e)
        {
            operator1 = "+";
            cando1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void button26_Click(object sender, EventArgs e)
        {
            operator1 = "-";
            cando1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void button27_Click(object sender, EventArgs e)
        {
            operator1 = "*";
            cando1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void button28_Click(object sender, EventArgs e)
        {
            operator1 = "/";
            cando1 = double.Parse(textBox1.Text);
            textBox1.Clear();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            cando2 = double.Parse(textBox1.Text);
            switch (operator1)
            {
                case "+":
                    resultdo = cando1 + cando2;
                    textBox1.Text = resultdo.ToString();
                    history_box.Text += cando1 + "+" + cando2 + " = " + resultdo + "\n";
                    break;

                case "-":
                    resultdo = cando1 - cando2;
                    textBox1.Text = resultdo.ToString();
                    history_box.Text += cando1 + "-" + cando2 + " = " + resultdo + "\n";
                    break;

                case "*":
                    resultdo = cando1 * cando2;
                    textBox1.Text = resultdo.ToString();
                    history_box.Text += cando1 + "x" + cando2 + " = " + resultdo + "\n";
                    break;

                case "/":
                    resultdo = cando1 / cando2;
                    textBox1.Text = resultdo.ToString();
                    history_box.Text += cando1 + "/" + cando2 + " = " + resultdo + "\n";
                    break;

                case "Mod":
                    resultdo = cando1 % cando2;
                    textBox1.Text = resultdo.ToString();
                    history_box.Text += cando1 + "mod" + cando2 + " = " + resultdo + "\n";
                    break;

                case "Exp":
                    resultdo = (cando1 * Math.Pow(10, cando2));
                    textBox1.Text = resultdo.ToString();
                    history_box.Text += cando1 + " Exp " + cando2 + " = " + resultdo + "\n";
                    break;
                default:
                    break;

            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            cando1 = double.Parse(textBox1.Text);
            resultdo = cando1;
            textBox1.Text = Math.Pow(cando1, 3).ToString();


        }

        private void button6_Click(object sender, EventArgs e)
        {
            cando1 = double.Parse(textBox1.Text);
            resultdo = cando1;
            textBox1.Text = Math.Pow(cando1, 2).ToString();

        }

        private void button16_Click(object sender, EventArgs e)
        {
            cando1 = double.Parse(textBox1.Text);
            resultdo = cando1;
            textBox1.Text = Math.Pow(cando1, -1).ToString();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            cando1 = double.Parse(textBox1.Text);
            resultdo = cando1;
            textBox1.Text = Math.Pow(10, cando1).ToString();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            history_box.Clear();
            memo_box.Clear();
            memory1 = 0;
            memory2 = 0;
            cando1 = 0;
            cando2 = 0;
            textBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 0 && (!textBox1.Text.EndsWith("-")))
            {
                memory1 = Convert.ToDouble(textBox1.Text);
                memory2 = memory2 - memory1;
                memo_box.Text += memory2 + "\n".ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 0 && (!textBox1.Text.EndsWith("-")))
            {
                memory1 = Convert.ToDouble(textBox1.Text);
                memory2 = memory2 + memory1;
                memo_box.Text += memory2 + "\n".ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            memory1 = 0;
            memory2 = 0;
            memo_box.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 1)
            {
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1, 1);
            }
            if (textBox1.Text.Length == 1)
            {
                textBox1.Text = "0";
                initia = true;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            operator1 = "Exp";
            cando1 = double.Parse(textBox1.Text);
            textBox1.Clear();

        }

        private void button12_Click(object sender, EventArgs e)
        {
            operator1 = "Mod";
            cando1 = double.Parse(textBox1.Text);
            textBox1.Clear();


        }

        private void percentage_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 0 && cando1 != 0)
            {
                cando2 = double.Parse(textBox1.Text);
                cando2 = (cando1 / 100) * cando2;
                textBox1.Text = cando2.ToString();
            }
            else
                textBox1.Text = "0";
        }

        private void convert_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 0 && listBox1.SelectedIndex > -1)
            {
                String choice = listBox1.SelectedItem.ToString();
                if (choice == "USD -> THB")
                {
                    double USD = Convert.ToDouble(textBox1.Text);
                    textBox1.Text = (USD * 30.3).ToString();
                    history_box.Text += USD + "$ = " + textBox1.Text+"THB";
                }
                else if (choice == "THB -> USD")
                {
                    double THB = Convert.ToDouble(textBox1.Text);
                    textBox1.Text = (THB / 30.3).ToString();
                    history_box.Text += THB + "THB = " + textBox1.Text + "USD";
                }
            }
        }
    }
}
